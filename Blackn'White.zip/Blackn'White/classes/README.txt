== DROP YOUR CUSTOM CLASSES HERE ==

How to use:

[HAXE]	new ModClass("My Class File");