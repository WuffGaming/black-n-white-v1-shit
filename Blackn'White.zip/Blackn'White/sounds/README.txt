== DROP YOUR CUSTOM .OGG SOUNDS HERE ==

Example Tree:
└───sounds
    │   sfx.ogg

Sounds here can be played this way:

[HAXE]	FlxG.sound.play(Paths.sound("sfx"));
[LUA]	playSound("sfx")