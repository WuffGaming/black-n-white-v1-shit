== DROP YOUR CUSTOM STAGES FILES HERE (JSON & SCRIPT) ==

To create stages, use the Stage Editor in the Toolbox.

Example Character Tree:
└───stages
    │   My Stage.hx
    │   My Stage.json
