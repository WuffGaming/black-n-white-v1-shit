== DROP YOUR CHARACTERS FOLDERS HERE ==

Example Character Tree:
└───characters
    └───your char
	│   spritesheet.xml
	│   spritesheet.png
	│   character.hx
	│   character.json
	│   icon.png

Psych Engine characters are also supported. Drop the JSON here and drop the character files in the "images" folder like you would do on a Psych installation.