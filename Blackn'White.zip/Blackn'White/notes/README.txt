== DROP YOUR CUSTOM NOTE TYPES SCRIPTS HERE ==

Example Tree:
└───characters
    │   My Custom Note Type.hx
    │   My Second Custom Note Type.hx

They will automatically be detected by the charter in the "Add Note Type" screen.