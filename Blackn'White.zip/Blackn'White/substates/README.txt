== DROP YOUR CUSTOM SUBSTATES HERE ==

Example Tree:
└───substates
    │   My Custom Substate.hx

Substates can be opened this way:

[HAXE]	openSubState(new ModSubState("My Custom Substate"));