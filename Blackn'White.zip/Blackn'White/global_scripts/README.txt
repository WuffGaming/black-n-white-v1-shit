== DROP ANY SCRIPTS HERE ==

Scripts dropped in this folder will be executed on every song.