== DROP YOUR CUSTOM VIDEOS HERE ==

For example, if you want a video cutscene to play for the song "Shrexophone", add this file:
"shrexophone-cutscene.mp4"
Same can be done for end cutscenes ("shrexophone-end-cutscene.mp4")